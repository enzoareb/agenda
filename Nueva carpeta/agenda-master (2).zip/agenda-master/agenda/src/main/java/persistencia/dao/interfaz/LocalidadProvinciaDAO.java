package persistencia.dao.interfaz;

import java.util.List;

import dto.LocalidadProvinciaDTO;

public interface LocalidadProvinciaDAO {
	public List<LocalidadProvinciaDTO> readAll();
}
